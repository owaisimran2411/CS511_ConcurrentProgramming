/*
 * Name: Muhammad Owais Imran
 * Course: CS511-A
 * Assignment: 03 (ERLang)
 * Due Date: Nov 5th, 2023
*/