Student Submission Information

/*
 * Name: Muhammad Owais Imran
 * Course: CS511-A
 * Assignment: 01 (Threads)
 * Due Date: Sep 17th, 2023
*/